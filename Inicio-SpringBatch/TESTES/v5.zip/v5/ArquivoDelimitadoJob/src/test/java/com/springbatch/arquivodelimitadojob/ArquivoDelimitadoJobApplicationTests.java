package com.springbatch.arquivodelimitadojob;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ArquivoDelimitadoJobApplicationTests {

	@Test
	void contextLoads() {
	}

}
