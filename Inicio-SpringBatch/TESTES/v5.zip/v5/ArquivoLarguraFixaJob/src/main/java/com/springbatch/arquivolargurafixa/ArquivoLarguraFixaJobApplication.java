package com.springbatch.arquivolargurafixa;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ArquivoLarguraFixaJobApplication {

	public static void main(String[] args) {
		SpringApplication.run(ArquivoLarguraFixaJobApplication.class, args);
	}

}
