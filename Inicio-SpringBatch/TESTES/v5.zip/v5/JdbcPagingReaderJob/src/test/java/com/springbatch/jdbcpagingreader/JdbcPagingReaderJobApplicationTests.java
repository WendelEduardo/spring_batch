package com.springbatch.jdbcpagingreader;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class JdbcPagingReaderJobApplicationTests {

	@Test
	void contextLoads() {
	}

}
