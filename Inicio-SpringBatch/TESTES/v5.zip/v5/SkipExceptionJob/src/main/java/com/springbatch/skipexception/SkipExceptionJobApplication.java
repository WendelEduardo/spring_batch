package com.springbatch.skipexception;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SkipExceptionJobApplication {

	public static void main(String[] args) {
		SpringApplication.run(SkipExceptionJobApplication.class, args);
	}

}
