package com.springbatch.skipexception;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SkipExceptionJobApplicationTests {

	@Test
	void contextLoads() {
	}

}
